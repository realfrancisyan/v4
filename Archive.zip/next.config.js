const withImages = require('next-images');
module.exports = withImages({
    distDir: '_next'
});
