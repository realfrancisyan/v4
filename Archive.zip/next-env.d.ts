/// <reference types="next" />
/// <reference types="next/types/global" />
declare module '*.css';
declare module '*.svg';
declare module '*.jpg';
declare module '*.png';
declare module 'curve-js-sdk';
